//strict mode
"use strict";

//import functions
import {whisper} from "./whisper.js";





